# ARCON — Company Website

A fully animated, mobile-responsive landing page for ARCON (civil construction,
infrastructure & premium real estate). Built with React 19, Tailwind CSS v4,
Motion, and Vite.

## Run it locally

You need [Node.js](https://nodejs.org) (v18 or newer) installed.

```bash
# 1. Install dependencies (creates the node_modules folder)
npm install

# 2. Start the development server
npm run dev
```

Then open the URL shown in the terminal (usually http://localhost:5173).

## Build for production

```bash
npm run build      # outputs a ready-to-deploy site into the "dist" folder
npm run preview    # preview the production build locally
```

Upload the contents of the `dist` folder to any static host (Netlify, Vercel,
GitHub Pages, cPanel, etc.) to put the site online.

## Sections

- **Hero** — full-screen auto-rotating slideshow (2 brand videos + 4 project photos)
- **About** — company profile with Vision / Mission / Promise
- **Projects** — portfolio of ARCON developments
- **Stats** — animated counters + logo-masked video
- **Values** — why ARCON
- **Contact** — enquiry form, office details, footer

## Editing content

- Hero slides: `src/components/Hero.jsx` (the `slides` array at the top)
- Projects: `src/components/Projects.jsx`
- Contact details / email / phone: `src/components/Contact.jsx`
- Colors & fonts: `src/index.css`
- Logo: `src/components/Logo.jsx`

> Note: the project photos are stock placeholders. Replace the `img` URLs in
> `Hero.jsx` and `Projects.jsx` with your own project renders.
