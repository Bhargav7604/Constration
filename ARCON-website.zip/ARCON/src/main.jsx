import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'

// Note: StrictMode is intentionally omitted. Its dev-only double-mount
// cancels Framer Motion's on-mount `animate` transitions, freezing the
// hero slideshow's reveal at its initial (hidden) state.
createRoot(document.getElementById('root')).render(<App />)
