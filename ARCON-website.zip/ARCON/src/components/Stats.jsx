import { motion } from "motion/react";
import { AnimatedCounter, Typewriter } from "./Animated";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.06 } },
};

const gridVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.06, delayChildren: 0.1 } },
};

const statVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: "easeOut" } },
};

const stats = [
  { value: 35, suffix: "+", label: "Years Of Experience" },
  { value: 12, suffix: "+", label: "Landmark Projects Delivered" },
  { value: 1200, suffix: "+", label: "Families Given A Home" },
  { value: 99.5, decimals: 1, suffix: "%", label: "On-Time Handover Rate" },
  { value: 10, suffix: "L+", label: "Sq. Ft. Constructed" },
];

const maskUrl = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cpath d='m53.54,45.42c2.19-3.79,7.67-3.79,9.86,0l4.54,7.87c1.17,2.02,1.17,4.51,0,6.54l-8.15,13.81c-1.68,2.91.42,6.55,3.78,6.55h17.81c3.45,0,5.61-3.74,3.89-6.73l-28.76-49.81c-2.95-5.12-10.34-5.12-13.29,0l-28.46,49.3c-1.86,3.22.46,7.24,4.18,7.24h10.23c2.55,0,4.91-1.36,6.19-3.57l18.18-31.19Z'/%3E%3C/svg%3E")`;

export default function Stats() {
  return (
    <section
      id="stats"
      className="w-full overflow-hidden border-t border-white/10 bg-black px-6 py-8 text-white md:px-12 md:py-24 lg:px-[120px]"
    >
      <div className="mx-auto w-full max-w-[1440px]">
        <div className="flex flex-col items-stretch gap-16 lg:flex-row lg:gap-[160px]">
          {/* Left column */}
          <motion.div
            className="flex flex-1 flex-col justify-start"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={containerVariants}
          >
            <h2 className="mb-6 w-[590px] max-w-full text-[clamp(1.5rem,4vw,3.5rem)] font-medium leading-[1.1] tracking-tight">
              <Typewriter text="Building Spaces" delay={0} speed={0.012} />
              <br />
              <Typewriter text="that " delay={0.25} speed={0.012} />
              <span className="font-dm-serif italic font-normal">
                <Typewriter text="Elevate Your Living" delay={0.35} speed={0.012} />
              </span>
            </h2>

            <p className="mb-16 max-w-lg whitespace-normal text-base font-light leading-relaxed text-white/40 md:text-lg">
              <Typewriter
                text="For over three decades, homeowners and investors across Maharashtra have trusted our engineering teams and modern equipment to raise buildings that are structurally sound, delivered on time, and built to last."
                delay={0.1}
                speed={0.012}
              />
            </p>

            <motion.div
              className="grid grid-cols-2 gap-8 md:grid-cols-[max-content_max-content] md:gap-x-16 lg:gap-x-24"
              variants={gridVariants}
            >
              {stats.map((s) => (
                <motion.div key={s.label} className="flex flex-col" variants={statVariants}>
                  <span className="mb-3 font-dm-serif text-4xl tracking-tight md:text-5xl lg:text-[56px]">
                    <AnimatedCounter
                      value={s.value}
                      suffix={s.suffix}
                      decimals={s.decimals || 0}
                    />
                  </span>
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-white/40 md:text-xs">
                    {s.label}
                  </span>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>

          {/* Right column: logo-masked video */}
          <div className="flex shrink-0 items-center justify-center lg:w-1/2 lg:justify-end">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1.2 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, delay: 0, ease: "easeOut" }}
              className="aspect-square w-full max-w-[500px] origin-center lg:w-[120%] lg:max-w-none"
              style={{
                WebkitMaskImage: maskUrl,
                WebkitMaskSize: "contain",
                WebkitMaskRepeat: "no-repeat",
                WebkitMaskPosition: "center",
                maskImage: maskUrl,
                maskSize: "contain",
                maskRepeat: "no-repeat",
                maskPosition: "center",
              }}
            >
              <video
                autoPlay
                loop
                muted
                playsInline
                className="h-full w-full object-cover"
              >
                <source
                  src="https://app-uploads.krea.ai/wan-videos/7f348c17-c3aa-40c9-9d5b-a2bed9a72c2e.mp4"
                  type="video/mp4"
                />
              </video>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
