import { useState } from "react";
import { motion } from "motion/react";
import LogoMark from "./Logo";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
};

export default function Contact() {
  const [sent, setSent] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <section
      id="contact"
      className="w-full border-t border-white/10 bg-black px-6 py-20 text-white md:px-12 md:py-28 lg:px-[120px]"
    >
      <div className="mx-auto grid w-full max-w-[1440px] gap-16 lg:grid-cols-2 lg:gap-24">
        {/* Left: details */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={{ visible: { transition: { staggerChildren: 0.1 } } }}
        >
          <motion.span
            variants={fadeUp}
            className="mb-4 block text-xs font-semibold uppercase tracking-[0.3em] text-gold-light"
          >
            Get in touch
          </motion.span>
          <motion.h2
            variants={fadeUp}
            className="mb-8 text-[clamp(1.75rem,4vw,3rem)] font-medium leading-[1.15] tracking-tight"
          >
            Let's build your{" "}
            <span className="font-dm-serif italic font-normal text-gold-light">
              next landmark
            </span>
          </motion.h2>

          <motion.div variants={fadeUp} className="space-y-6 text-white/60">
            <div>
              <p className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-white/30">
                Office
              </p>
              <p className="font-light leading-relaxed">
                Office No 05, Sairaj Apartment, Ganraj Chowk,
                <br />
                Baner, Pune — 411045, Maharashtra, India
              </p>
            </div>
            <div>
              <p className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-white/30">
                Phone
              </p>
              <p className="font-light">
                <a href="tel:+918380944333" className="transition-colors hover:text-gold-light">
                  +91 83809 44333
                </a>
                {" · "}
                <a href="tel:+917009436575" className="transition-colors hover:text-gold-light">
                  +91 70094 36575
                </a>
              </p>
            </div>
            <div>
              <p className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-white/30">
                Email
              </p>
              <p className="font-light">
                <a
                  href="mailto:info@arconinfra.com"
                  className="transition-colors hover:text-gold-light"
                >
                  info@arconinfra.com
                </a>
              </p>
            </div>
          </motion.div>
        </motion.div>

        {/* Right: form */}
        <motion.form
          onSubmit={handleSubmit}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="flex flex-col gap-5 rounded-2xl border border-white/10 bg-gradient-to-br from-white/[0.04] to-transparent p-7 md:p-10"
        >
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Name" name="name" placeholder="Your name" />
            <Field label="Phone" name="phone" type="tel" placeholder="Your number" />
          </div>
          <Field label="Email" name="email" type="email" placeholder="you@email.com" />
          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-white/40">
              Message
            </label>
            <textarea
              name="message"
              rows={4}
              placeholder="Tell us about your project…"
              className="resize-none rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white placeholder-white/25 outline-none transition-colors focus:border-gold/60"
            />
          </div>
          <button
            type="submit"
            className="mt-2 rounded-full bg-gold px-7 py-3.5 text-sm font-semibold text-black transition-transform hover:scale-[1.02]"
          >
            {sent ? "Thank you — we'll be in touch ✓" : "Send enquiry"}
          </button>
        </motion.form>
      </div>

      {/* Footer */}
      <footer className="mx-auto mt-24 flex w-full max-w-[1440px] flex-col items-center justify-between gap-6 border-t border-white/10 pt-10 md:flex-row">
        <div className="flex items-center gap-3">
          <LogoMark className="h-9 w-9" />
          <div className="flex flex-col leading-none">
            <span className="text-base font-bold tracking-[0.25em]">ARCON</span>
            <span className="text-[9px] font-light tracking-wide text-gold-light">
              It's not a home, it's a hideaway
            </span>
          </div>
        </div>
        <p className="text-xs text-white/30">
          © {2026} ARCON Infra. All rights reserved.
        </p>
        <p className="max-w-xs text-center text-[10px] italic text-white/25 md:text-right">
          Winners don't do different things. They do things differently.
        </p>
      </footer>
    </section>
  );
}

function Field({ label, name, type = "text", placeholder }) {
  return (
    <div className="flex flex-col gap-2">
      <label className="text-[11px] font-semibold uppercase tracking-wider text-white/40">
        {label}
      </label>
      <input
        type={type}
        name={name}
        placeholder={placeholder}
        className="rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white placeholder-white/25 outline-none transition-colors focus:border-gold/60"
      />
    </div>
  );
}
