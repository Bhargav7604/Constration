import { motion } from "motion/react";

const values = [
  {
    icon: "M3 21h18M5 21V7l7-4 7 4v14M9 21v-6h6v6",
    title: "Leadership & Innovation",
    text: "A step ahead of the curve on safety advancements, workforce training and the latest proven construction technologies.",
  },
  {
    icon: "M12 2l2.4 7.4H22l-6 4.6 2.3 7.4L12 17l-6.3 4.4L8 14 2 9.4h7.6z",
    title: "Uncompromising Quality",
    text: "Major complex works handled by highly experienced management and engineering teams, from preliminary design to completion.",
  },
  {
    icon: "M4 7V4h16v3M9 20h6M12 4v16",
    title: "Versatility & Adaptability",
    text: "A full-service civil contractor expanding across every discipline of construction, responsive and adaptable to change.",
  },
  {
    icon: "M12 3v18M3 12h18M5.6 5.6l12.8 12.8M18.4 5.6L5.6 18.4",
    title: "Modern Fleet & Equipment",
    text: "A large modern fleet of plant and equipment — excavators, dump trucks, dozers and graders — deployed on every site.",
  },
  {
    icon: "M9 12l2 2 4-4M21 12a9 9 0 11-18 0 9 9 0 0118 0z",
    title: "Green Environment",
    text: "Committed to environmental excellence and sustainable development, minimizing our footprint on every project.",
  },
  {
    icon: "M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m6-1.13a4 4 0 10-4-4 4 4 0 004 4z",
    title: "People First",
    text: "Our people are our most important asset — we invest in training, apprenticeships and continued education across trades.",
  },
];

const card = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
};

export default function Values() {
  return (
    <section
      id="values"
      className="w-full border-t border-white/10 bg-black px-6 py-20 text-white md:px-12 md:py-28 lg:px-[120px]"
    >
      <div className="mx-auto w-full max-w-[1440px]">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="mb-14 max-w-2xl"
        >
          <span className="mb-4 block text-xs font-semibold uppercase tracking-[0.3em] text-gold-light">
            Why ARCON
          </span>
          <h2 className="text-[clamp(1.75rem,4vw,3rem)] font-medium leading-[1.15] tracking-tight">
            The values we{" "}
            <span className="font-dm-serif italic font-normal text-gold-light">
              build on
            </span>
          </h2>
        </motion.div>

        <motion.div
          className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={{ visible: { transition: { staggerChildren: 0.08 } } }}
        >
          {values.map((v) => (
            <motion.div
              key={v.title}
              variants={card}
              whileHover={{ y: -6 }}
              className="group rounded-2xl border border-white/10 bg-gradient-to-br from-white/[0.04] to-transparent p-7 transition-colors hover:border-gold/40"
            >
              <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-gold/15 text-gold-light transition-colors group-hover:bg-gold group-hover:text-black">
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-6 w-6"
                >
                  <path d={v.icon} />
                </svg>
              </div>
              <h3 className="mb-2 text-lg font-semibold tracking-tight">
                {v.title}
              </h3>
              <p className="text-sm font-light leading-relaxed text-white/50">
                {v.text}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
