import { motion } from "motion/react";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
};

const pillars = [
  {
    title: "Vision",
    text: "To be Maharashtra's most trusted name in construction — rewriting the region's real-estate story one landmark at a time.",
  },
  {
    title: "Mission",
    text: "To deliver complete, end-to-end solutions for real-estate construction with uncompromising quality, transparency and timeliness.",
  },
  {
    title: "Promise",
    text: "It's not a home, it's a hideaway. Every space we build is designed to be lived in, loved, and passed down.",
  },
];

export default function About() {
  return (
    <section
      id="about"
      className="w-full border-t border-white/10 bg-black px-6 py-20 text-white md:px-12 md:py-28 lg:px-[120px]"
    >
      <div className="mx-auto grid w-full max-w-[1440px] gap-16 lg:grid-cols-2 lg:gap-24">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={{ visible: { transition: { staggerChildren: 0.12 } } }}
        >
          <motion.span
            variants={fadeUp}
            className="mb-4 block text-xs font-semibold uppercase tracking-[0.3em] text-gold-light"
          >
            Who we are
          </motion.span>
          <motion.h2
            variants={fadeUp}
            className="mb-8 text-[clamp(1.75rem,4vw,3rem)] font-medium leading-[1.15] tracking-tight"
          >
            A certified multi-discipline{" "}
            <span className="font-dm-serif italic font-normal text-gold-light">
              construction group
            </span>
          </motion.h2>
          <motion.p
            variants={fadeUp}
            className="mb-6 text-base font-light leading-relaxed text-white/50 md:text-lg"
          >
            ARCON is a certified multi-discipline engineering, contracting and
            construction company headquartered in Pune, Maharashtra. Since
            inception, we have been actively engaged in civil contracting and
            infrastructure development for both public and private sector
            clients across the state.
          </motion.p>
          <motion.p
            variants={fadeUp}
            className="text-base font-light leading-relaxed text-white/50 md:text-lg"
          >
            Floated by ambitious, hardworking and dynamic individuals, ARCON has
            undergone rapid expansion — diversifying into large-scale projects
            through direct tenders and strategic joint ventures with reputed
            construction partners.
          </motion.p>
        </motion.div>

        <motion.div
          className="flex flex-col gap-6"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={{ visible: { transition: { staggerChildren: 0.12 } } }}
        >
          {pillars.map((p) => (
            <motion.div
              key={p.title}
              variants={fadeUp}
              whileHover={{ x: 8 }}
              className="group rounded-2xl border border-white/10 bg-gradient-to-br from-white/[0.04] to-transparent p-6 transition-colors hover:border-gold/40 md:p-8"
            >
              <h3 className="mb-2 font-dm-serif text-2xl text-gold-light md:text-3xl">
                {p.title}
              </h3>
              <p className="text-sm font-light leading-relaxed text-white/50 md:text-base">
                {p.text}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
