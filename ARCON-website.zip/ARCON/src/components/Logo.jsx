// ARCON brand mark — a golden building tile with an ascending skyline,
// rebuilt from the original MGR Infra logo concept.
export default function LogoMark({ className = "" }) {
  return (
    <svg viewBox="0 0 100 100" className={className} xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="arcon-gold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#e6c274" />
          <stop offset="0.5" stopColor="#c99a3f" />
          <stop offset="1" stopColor="#9c7226" />
        </linearGradient>
      </defs>
      <rect width="100" height="100" rx="6" fill="url(#arcon-gold)" />
      {/* Ascending skyline of towers */}
      <g fill="#fff">
        <rect x="28" y="60" width="4.5" height="20" />
        <rect x="36.5" y="52" width="4.5" height="28" />
        <rect x="45" y="43" width="4.5" height="37" />
        <rect x="53.5" y="34" width="4.5" height="46" />
        <rect x="62" y="25" width="4.5" height="55" />
      </g>
      {/* Diagonal roofline accent */}
      <path d="M27 60 L68 23 L68 27 L31 62 Z" fill="#fff" opacity="0.55" />
    </svg>
  );
}
