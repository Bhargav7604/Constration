import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";

// Full-screen auto-rotating slideshow, inspired by leading construction-brand
// landing pages. First two slides are ARCON brand films; the rest are projects.
const slides = [
  {
    tag: "Welcome to ARCON",
    name: "Building Landmarks",
    location: "That Stand for Generations",
    config: "Civil construction, infrastructure & premium real estate across Maharashtra, India.",
    video: "https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260503_144509_89e2d612-8af2-45c3-90f4-4831bc60715d.mp4",
  },
  {
    tag: "35+ Years of Trust",
    name: "Crafted to Endure",
    location: "Delivered On Time",
    config: "From foundation to finish — engineering excellence on every project we undertake.",
    video: "https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260403_050628_c4e32401-fab4-4a27-b7a8-6e9291cd5959.mp4",
  },
  {
    tag: "Upcoming Flagship",
    name: "Sarvoday Glory",
    location: "Mulund West, Mumbai",
    config: "520 Smart 1 & 1.5 BHK Residences + Retail",
    img: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1920&q=80",
  },
  {
    tag: "Now Building",
    name: "Silver Arch",
    location: "Talegaon, Pune",
    config: "200 Premium 1 & 2 BHK Apartments",
    img: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1920&q=80",
  },
  {
    tag: "Commercial + Residential",
    name: "Sky One",
    location: "Nashik",
    config: "41 Shops, Offices & 224 Premium Flats",
    img: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1920&q=80",
  },
  {
    tag: "Now Building",
    name: "Sky II Cosmos",
    location: "Pimple Saudagar, Pune",
    config: "30 Premium 1 & 2 BHK Flats + Shops",
    img: "https://images.unsplash.com/photo-1481253127861-534498168948?auto=format&fit=crop&w=1920&q=80",
  },
];

const DURATION = 6000;

// Single element that fades + slides up on mount, after `delay` seconds.
function Reveal({ as = "div", delay = 0, className = "", children }) {
  const MotionTag = motion[as];
  return (
    <MotionTag
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, delay, ease: "easeOut" }}
      className={className}
    >
      {children}
    </MotionTag>
  );
}

export default function Hero() {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);

  const go = useCallback((i) => setIndex(((i % slides.length) + slides.length) % slides.length), []);

  useEffect(() => {
    if (paused) return;
    const t = setTimeout(() => go(index + 1), DURATION);
    return () => clearTimeout(t);
  }, [index, paused, go]);

  const slide = slides[index];

  return (
    <section
      id="top"
      className="relative h-screen min-h-[600px] w-full overflow-hidden bg-black"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {/* Crossfading slides — video brand films or Ken Burns project photos */}
      <AnimatePresence>
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.1, ease: "easeInOut" }}
          className="absolute inset-0 overflow-hidden"
        >
          {slide.video ? (
            <video
              key={slide.video}
              autoPlay
              loop
              muted
              playsInline
              className="h-full w-full object-cover"
            >
              <source src={slide.video} type="video/mp4" />
            </video>
          ) : (
            <motion.img
              src={slide.img}
              alt={slide.name}
              initial={{ scale: 1.08 }}
              animate={{ scale: 1.22 }}
              transition={{ duration: DURATION / 1000 + 1.2, ease: "linear" }}
              className="h-full w-full object-cover"
            />
          )}
        </motion.div>
      </AnimatePresence>

      {/* Overlays for legibility — kept light so the photo stays vivid */}
      <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/35 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/10" />

      {/* Content — each element animates in with an explicit staggered delay.
          The keyed wrapper remounts on slide change so the reveal replays. */}
      <div className="relative z-10 flex h-full items-center">
        <div className="mx-auto w-full max-w-[1440px] px-6 md:px-12 lg:px-[120px]">
          <div key={index} className="max-w-3xl">
            <Reveal delay={0.15} className="mb-5 flex items-center gap-3">
              <span className="h-px w-10 bg-gold" />
              <span className="text-xs font-semibold uppercase tracking-[0.35em] text-gold-light md:text-sm">
                {slide.tag}
              </span>
            </Reveal>

            <Reveal
              as="h1"
              delay={0.28}
              className="text-[clamp(2.5rem,7vw,6rem)] font-medium leading-[1.02] tracking-tight text-white"
            >
              {slide.name}
            </Reveal>

            <Reveal
              as="p"
              delay={0.4}
              className="mt-4 font-dm-serif text-2xl italic text-gold-light md:text-3xl"
            >
              {slide.location}
            </Reveal>

            <Reveal
              as="p"
              delay={0.52}
              className="mt-3 max-w-xl text-base font-light leading-relaxed text-white/60 md:text-lg"
            >
              {slide.config}
            </Reveal>

            <Reveal delay={0.64} className="mt-9 flex flex-wrap items-center gap-4">
              <a
                href="#projects"
                className="group flex items-center gap-2 rounded-full bg-gold px-7 py-3.5 text-sm font-semibold text-black transition-transform hover:scale-105"
              >
                Know more
                <span className="transition-transform group-hover:translate-x-1">→</span>
              </a>
              <a
                href="#contact"
                className="rounded-full border border-white/30 px-7 py-3.5 text-sm font-semibold text-white backdrop-blur-sm transition-colors hover:border-gold hover:text-gold-light"
              >
                Enquire now
              </a>
            </Reveal>
          </div>
        </div>
      </div>

      {/* Slide controls */}
      <div className="absolute bottom-8 left-0 z-20 w-full">
        <div className="mx-auto flex w-full max-w-[1440px] items-center justify-between px-6 md:px-12 lg:px-[120px]">
          {/* Dots + progress */}
          <div className="flex items-center gap-3">
            {slides.map((s, i) => (
              <button
                key={s.name}
                onClick={() => go(i)}
                aria-label={`Go to ${s.name}`}
                className="group relative h-1.5 overflow-hidden rounded-full bg-white/25 transition-all"
                style={{ width: i === index ? 44 : 18 }}
              >
                {i === index && !paused && (
                  <motion.span
                    key={index}
                    initial={{ scaleX: 0 }}
                    animate={{ scaleX: 1 }}
                    transition={{ duration: DURATION / 1000, ease: "linear" }}
                    className="absolute inset-0 origin-left bg-gold"
                  />
                )}
                {i === index && paused && <span className="absolute inset-0 bg-gold" />}
              </button>
            ))}
          </div>

          {/* Counter + arrows */}
          <div className="flex items-center gap-5">
            <span className="hidden font-dm-serif text-lg text-white/50 sm:block">
              <span className="text-gold-light">0{index + 1}</span> / 0{slides.length}
            </span>
            <div className="flex gap-2">
              <button
                onClick={() => go(index - 1)}
                aria-label="Previous slide"
                className="flex h-11 w-11 items-center justify-center rounded-full border border-white/25 text-white transition-colors hover:border-gold hover:bg-gold hover:text-black"
              >
                ←
              </button>
              <button
                onClick={() => go(index + 1)}
                aria-label="Next slide"
                className="flex h-11 w-11 items-center justify-center rounded-full border border-white/25 text-white transition-colors hover:border-gold hover:bg-gold hover:text-black"
              >
                →
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
