import { motion } from "motion/react";

const projects = [
  {
    name: "Sky One",
    location: "Nashik",
    status: "Ongoing",
    detail: "41 Shops, Offices & 224 Flats",
    size: "1,90,000 Sq.Ft.",
    type: "Commercial + Residential",
  },
  {
    name: "Sarvoday Glory",
    location: "Mulund West, Mumbai",
    status: "Upcoming",
    detail: "520 Smart 1 & 1.5 BHK Flats + Retail",
    size: "4,00,000 Sq.Ft.",
    type: "Residential + Commercial",
  },
  {
    name: "Silver Arch",
    location: "Talegaon, Pune",
    status: "Ongoing",
    detail: "200 Premium 1 & 2 BHK Flats",
    size: "1,60,000 Sq.Ft.",
    type: "Residential",
  },
  {
    name: "Somnath Mahadev CHSL",
    location: "Ghatkopar East, Mumbai",
    status: "Ongoing",
    detail: "96 Flats + Ground/First floor retail",
    size: "80,000 Sq.Ft.",
    type: "Residential + Commercial",
  },
  {
    name: "Sky II Cosmos",
    location: "Pimple Saudagar, Pune",
    status: "Ongoing",
    detail: "30 Premium 1 & 2 BHK Flats + Shops",
    size: "30,000 Sq.Ft.",
    type: "Residential + Commercial",
  },
  {
    name: "Nalini CHSL",
    location: "Ambernath",
    status: "Completed",
    detail: "26 Premium 1 & 2 BHK Flats + Shops",
    size: "18,000 Sq.Ft.",
    type: "Residential",
  },
];

const statusStyles = {
  Ongoing: "bg-gold/15 text-gold-light border-gold/30",
  Upcoming: "bg-blue-400/10 text-blue-300 border-blue-400/25",
  Completed: "bg-emerald-400/10 text-emerald-300 border-emerald-400/25",
};

const card = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
};

export default function Projects() {
  return (
    <section
      id="projects"
      className="w-full border-t border-white/10 bg-black px-6 py-20 text-white md:px-12 md:py-28 lg:px-[120px]"
    >
      <div className="mx-auto w-full max-w-[1440px]">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="mb-14 max-w-2xl"
        >
          <span className="mb-4 block text-xs font-semibold uppercase tracking-[0.3em] text-gold-light">
            Project portfolio
          </span>
          <h2 className="text-[clamp(1.75rem,4vw,3rem)] font-medium leading-[1.15] tracking-tight">
            Landmarks across{" "}
            <span className="font-dm-serif italic font-normal text-gold-light">
              Maharashtra
            </span>
          </h2>
        </motion.div>

        <motion.div
          className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={{ visible: { transition: { staggerChildren: 0.08 } } }}
        >
          {projects.map((p) => (
            <motion.article
              key={p.name}
              variants={card}
              whileHover={{ y: -8 }}
              className="group relative flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-white/[0.05] to-transparent p-6 transition-colors hover:border-gold/40 md:p-8"
            >
              <div
                className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-gold/10 blur-2xl transition-opacity duration-500 group-hover:opacity-100 opacity-0"
              />
              <div className="mb-6 flex items-start justify-between gap-3">
                <span
                  className={`rounded-full border px-3 py-1 text-[10px] font-semibold uppercase tracking-wider ${statusStyles[p.status]}`}
                >
                  {p.status}
                </span>
                <span className="font-dm-serif text-lg text-gold-light">
                  {p.size}
                </span>
              </div>
              <h3 className="mb-1 text-2xl font-semibold tracking-tight">
                {p.name}
              </h3>
              <p className="mb-4 text-sm text-white/40">{p.location}</p>
              <p className="mt-auto text-sm font-light leading-relaxed text-white/60">
                {p.detail}
              </p>
              <p className="mt-3 text-[11px] font-semibold uppercase tracking-wider text-white/30">
                {p.type}
              </p>
            </motion.article>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
