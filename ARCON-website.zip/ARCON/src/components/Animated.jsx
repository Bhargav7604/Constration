import { useEffect, useRef } from "react";
import { motion, useInView, animate } from "motion/react";

// Counts up from 0 to `value` when scrolled into view.
export function AnimatedCounter({ value, suffix = "", prefix = "", decimals = 0 }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });

  useEffect(() => {
    if (!inView) return;
    const controls = animate(0, value, {
      duration: 1.5,
      ease: "easeOut",
      onUpdate(val) {
        if (ref.current) {
          ref.current.textContent = prefix + val.toFixed(decimals) + suffix;
        }
      },
    });
    return () => controls.stop();
  }, [inView, value, suffix, prefix, decimals]);

  return <span ref={ref}>{prefix}0{suffix}</span>;
}

// Character-by-character reveal, triggered on scroll into view.
export function Typewriter({ text, delay = 0, speed = 0.015, className = "" }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-10px" });

  const container = {
    hidden: { opacity: 1 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: speed, delayChildren: delay },
    },
  };
  const child = {
    hidden: { opacity: 0 },
    visible: { opacity: 1 },
  };

  return (
    <motion.span
      ref={ref}
      className={className}
      variants={container}
      initial="hidden"
      animate={inView ? "visible" : "hidden"}
    >
      {text.split("").map((char, i) => (
        <motion.span key={i} variants={child}>
          {char}
        </motion.span>
      ))}
    </motion.span>
  );
}
