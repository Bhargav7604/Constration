import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Projects from "./components/Projects";
import Stats from "./components/Stats";
import Values from "./components/Values";
import Contact from "./components/Contact";

export default function App() {
  return (
    <div className="min-h-screen bg-black font-sans text-white">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Projects />
        <Stats />
        <Values />
        <Contact />
      </main>
    </div>
  );
}
